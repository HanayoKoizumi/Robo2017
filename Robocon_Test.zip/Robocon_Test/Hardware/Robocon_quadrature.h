#ifndef 	__QUADRATURE_H__
#define 	__QUADRATURE_H__

#include "stm32f10x.h"

void Quadrature_decode_TIM1_Init(void);

#endif

