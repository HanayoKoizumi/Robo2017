#ifndef 	__DEBUG_H__
#define		__DEBUG_H__

#include "stm32f10x.h"

void KEY_EXTI_Init(void);


#endif

