#ifndef __RCC_CONF
#define __RCC_CONF

void RCC_Init(void);

#endif
