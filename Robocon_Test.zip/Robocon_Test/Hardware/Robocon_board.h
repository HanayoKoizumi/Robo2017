 #ifndef		__BOARD_H__
 #define		__BOARD_H__
 
 #include "stm32f10x_conf.h"
	
 void Robocon_PhoTriRacing_Board_Init(void);
 void Robocon_NVIC_Init(void);
	
	
 #endif

