#ifndef		__DAC_H__
#define		__DAC_H__


void DAC1_Init(void);

void DAC1_Set_Vol(float vol);

#endif 
