#ifndef __ROBOCON_ADC_H__
#define __ROBOCON_ADC_H__

#include "stm32f10x.h"

 void Current_ADGet_Init(void);
 
 extern volatile uint32_t Motor_Cur[3];

#endif

