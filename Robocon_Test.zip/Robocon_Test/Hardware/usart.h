#ifndef 	__USART_H__
#define 	__USART_H__



void USART1_Init(u32 bound);
void UART4_Init(u32 bound);

#endif

