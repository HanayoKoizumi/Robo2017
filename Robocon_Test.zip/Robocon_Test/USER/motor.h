#ifndef __MOTOR_H
#define __MOTOR_H

void Motor_Cal(void);
void Motor_Run(void);

extern uint8_t motion_mode;

#endif
